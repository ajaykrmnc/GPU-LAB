#ifndef ADD_MUL_H
#define ADD_MUL_H

void matrixTranspose(float *mat, float *res, int rows, int cols);

void matrixMul(float *mat1, float *mat2, float *res, int rows, int cols);

#endif
